"""ALFF: Automated Frameworks for Active-Learning Machine Learning Interatomic Potentials and Material Properties Calculation.

<img src="./_assets/image/logo_alff.svg" style="float: left; margin-right: 20px" width="120"/>

Developed by [C.Thang Nguyen](https://thangckt.github.io/).
"""

from pathlib import Path

ALFF_ROOT = Path(__file__).parent

try:
    from ._version import version as __version__  # ty:ignore
except ImportError:
    __version__ = "0.1_fallback"

__author__ = "C.Thang Nguyen"
__contact__ = "http://thangckt.github.io/email"


# warnings.filterwarnings(action="ignore", module=".*paramiko.*")
