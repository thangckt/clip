"""Utilities for Active Learning workflow."""

import numpy as np

from ase.io import read
from ase.units import Bohr
from clff.base import KEY as K


class D3ParamMD:
    """Different packages use different names for D3 parameters.
    This class to 'return' conventional names for D3 parameters for different packages used for MD.

    Notes:
        - The default cutoff values are `95 Bohr (50.2718 Angstrom)` for two-body dispersion calculations and `40 Bohr (21.1671 Angstrom)` for coordination number and three-body calculations, as in [ASE-DFTD3](https://ase-lib.org/ase/calculators/dftd3.html) package. Other packages may use different default values.
        - Some dftd3 parameters for DFT calculations support triple-body interactions, but most [MD packages](https://docs.lammps.org/pair_dispersion_d3.html) only support pairwise interactions. So the triple-body cutoff parameter is not included in this class.
    """

    def __init__(self, d3package: str = "sevenn"):
        self.d3package: str = d3package
        self.default_twobody_cutoff: float = 50.2718  # 2body cutoff in Angstrom
        self.default_cn_cutoff: float = 21.1671
        # self.default_threebody_cutoff: float = 21.1671  # 3body cutoff, not used in most MD packages
        params = self.get_params()  # set self.param_names and self.damping_map
        ### Store params
        self.param_names = params["params"]
        self.damping_map = params["damping_map"]
        return

    def get_params(self) -> dict:
        """Return D3 parameter names according to different packages."""
        if self.d3package == "lammps":
            params = self._d3_lammps()
        elif self.d3package == "sevenn":
            params = self._d3_sevenn()
        else:
            raise ValueError(f"Unsupported D3 package: {self.d3package}")
        return params

    def check_supported_damping(self, damping: str):
        """Check if the damping method is supported in the selected package."""
        params = self.get_params()
        if damping not in params["damping_map"].keys():
            raise ValueError(
                f"Damping method '{damping}' is not supported in package '{self.d3package}'. Supported methods: {list(params['damping_map'].keys())}"
            )
        return

    def _d3_lammps(self) -> dict:
        ### https://docs.lammps.org/pair_dispersion_d3.html
        ### use lammps' D3 in sevenn: https://github.com/MDIL-SNU/SevenNet/issues/246
        """Return D3 parameters using in LAMMPS's `dispersion/d3`."""
        return {
            "params": ["damping", "functional", "cutoff", "cn_cutoff"],
            "damping_map": {
                "zero": "original",
                "zerom": "zerom",
                "bj": "bj",
                "bjm": "bjm",
            },
        }

    def _d3_sevenn(self) -> dict:
        ### https://github.com/MDIL-SNU/SevenNet/tree/main/sevenn/pair_e3gnn
        """Return D3 parameters using in SevenNet's `e3gnn`."""
        return {
            "params": ["damping", "xc", "cutoff", "cnthr"],
            "damping_map": {
                "zero": "damp_zero",
                "zerom": "damp_zerom",
                "bj": "damp_bj",
                "bjm": "damp_bjm",
            },
        }

    @staticmethod
    def angstrom2bohr(angstrom_value: float) -> float:
        """Convert Angstrom to Bohr.

        Notes:
            in `simple-dftd3`, `60*Bohr` converts 60 Bohr to Angstrom.
        """
        # bohr_value = round(angstrom_value / 0.52917721, ndigits=2)
        bohr_value = angstrom_value / Bohr
        return bohr_value

    @staticmethod
    def angstrom2bohr2(angstrom_value: float) -> float:
        """Convert Angstrom to Bohr^2. To used in sevenn package."""
        bohr2_value = (angstrom_value / Bohr) ** 2
        return bohr2_value

    @staticmethod
    def bohr2angstrom(bohr_value: float) -> float:
        """Convert Bohr to Angstrom."""
        angstrom_value = bohr_value * Bohr
        return angstrom_value


# class D3ParamDFT(D3ParamMD):
#     """Different packages use different names for D3 parameters.
#     This class to 'return' conventional names for D3 parameters for different packages used for DFT calculations.
#     """

#     def __init__(self, d3package: str = "ase_dftd3"):
#         super().__init__(d3package=d3package)
#         return

#     def get_params(self) -> dict:
#         """Return D3 parameter names according to different packages."""
#         if self.d3package == "simple_dftd3":
#             params = self._d3_simple_dftd3()
#         elif self.d3package == "ase_dftd3":
#             params = self._d3_ase_dftd3()
#         else:
#             raise ValueError(f"Unsupported D3 package: {self.d3package}")
#         return params

#     def _d3_simple_dftd3(self) -> dict:
#         ### https://github.com/dftd3/simple-dftd3/blob/main/python/dftd3/ase.py
#         """Return D3 parameters using in dftd3-python."""
#         return {
#             "params": ["damping", "method"],
#             "damping_map": {
#                 "zero": "d3zero",
#                 "zerom": "d3zerom",
#                 "bj": "d3bj",
#                 "bjm": "d3bjm",
#                 "op": "d3op",
#             },
#         }

#     def _d3_ase_dftd3(self) -> dict:
#         ### https://ase-lib.org/ase/calculators/dftd3.html
#         """Return D3 parameters using in ASE's DFTD3."""
#         return {
#             "params": ["damping", "xc", "cutoff", "cnthr", "abc"],
#             "damping_map": {
#                 "zero": "zero",
#                 "zerom": "zerom",
#                 "bj": "bj",
#                 "bjm": "bjm",
#             },
#         }


class MLP2Lammps:
    """Convert MLP model to be used in LAMMPS."""

    def __init__(self, mlp_model: str = "sevenn"):
        self.mlp_model: str = mlp_model
        self._check_supported_model()
        return

    def convert(
        self,
        checkpoint: str,
        outfile: str = "deployed.pt",
        **kwargs,
    ):
        """Convert MLP model to LAMMPS format.

        Args:
            checkpoint (str): Path to checkpoint file of MLP model.
            outfile (str): Path to output LAMMPS potential file.
            **kwargs: Additional arguments for specific conversion methods.
        """
        if self.mlp_model == "sevenn":
            MLP2Lammps.convert_sevenn(checkpoint, outfile, **kwargs)
        elif self.mlp_model == "sevenn_mliap":
            MLP2Lammps.convert_sevenn_mliap(checkpoint, outfile, **kwargs)
        return

    def _check_supported_model(self):
        """Return supported MLP models."""
        supported_models = ["sevenn", "sevenn_mliap"]
        if self.mlp_model not in supported_models:
            raise ValueError(
                f"MLP model: {self.mlp_model} is unsupported. Available models: {supported_models}"
            )
        return

    @staticmethod
    def convert_sevenn(
        checkpoint: str,
        outfile: str = "deploy_sevenn",
        modal: str | None = None,
        enable_flash: bool = False,
        parallel_type=False,
        **kwargs,  # avoid breaking due to future additional arguments.
    ):
        ### https://github.com/MDIL-SNU/SevenNet/blob/main/sevenn/scripts/deploy.py
        """Convert sevenn model to be used in LAMMPS.

        Args:
            checkpoint (str): Path to checkpoint file of sevenn model.
            outfile (str): Path to output LAMMPS potential file.
            modal (str): Channel of multi-task model.
            parallel_type (bool): Convert to potential for run in parallel simulations.
            enable_flash (bool): Use flashTP.
            **kwargs: Additional arguments to avoid breaking the function signature when future additional arguments are added.

        Notes:
            Single mode: will generate file as "outfile.pt"
            Parallel mode: will generate files as "outfile/deployed_parallel_0.pt", "outfile/deployed_parallel_1.pt", ...
        """
        from sevenn.scripts.deploy import deploy, deploy_parallel

        kwargs.pop("enable_cueq", None)  # cueq is only supported in MLIAP interface

        if parallel_type:
            deploy_parallel(checkpoint, outfile, modal, use_flash=enable_flash, **kwargs)
        else:
            deploy(checkpoint, outfile, modal, use_flash=enable_flash, **kwargs)
        return

    @staticmethod
    def convert_sevenn_mliap(
        checkpoint: str,
        outfile: str = "deploy_sevenn_mliap.pt",
        modal: str | None = None,
        enable_cueq: bool = False,
        enable_flash: bool = False,
        enable_oeq: bool = False,
        **kwargs,  # avoid breaking due to future additional arguments.
    ):
        ### https://github.com/MDIL-SNU/SevenNet/blob/main/sevenn/main/sevenn_get_model.py
        """Convert sevenn model to be used in LAMMPS MLIAP.

        Args:
            checkpoint (str): Path to checkpoint file of sevenn model.
            outfile (str): Path to output LAMMPS potential file.
            modal (str): Channel of multi-task model.
            enable_cueq (bool): Use cueq. cuEquivariance is only supported in ML-IAP interface.
            enable_flash (bool): Use flashTP.
            enable_oeq (bool): Use oeq.
            **kwargs: Additional arguments to avoid breaking the function signature when future additional arguments are added.
        """
        try:
            import torch
            from sevenn.mliap import SevenNetMLIAPWrapper
        except Exception as e:
            raise ImportError(
                f"Error importing SevenNetMLIAPWrapper. \n{e} \nHints: This feature requires SevenNet 0.12. And make sure installing `lammps` from conda-forge channel."
            )

        mliap_module = SevenNetMLIAPWrapper(
            model_path=checkpoint,
            modal=modal,
            use_cueq=enable_cueq,
            use_flash=enable_flash,
            use_oeq=enable_oeq,
            **kwargs,
        )
        torch.save(mliap_module, outfile)
        return


def sort_task_dirs(task_dirs: list[str]) -> list[str]:
    """Sort the structure paths by its supercell size.

    This helps to chunk the tasks with similar supercell size together (similar supercell size means similar k-point number), which then lead to running DFT calculations in similar time, avoiding the situation that some tasks are finished while others are still running.

    Notes:
        - `np.lexsort()` is used to sort by multiple keys (np.arrays) in order.
        - `task_dirs` must be relative with `run_dir`, not `work_dir`.
    """
    struct_list = [
        read(f"{p}/{K.FILE_FRAME_UNLABEL}", format="extxyz", index=-1) for p in task_dirs
    ]

    atom_num = np.array([len(struct) for struct in struct_list])
    compo_num = np.array([struct.get_chemical_formula() for struct in struct_list])  # ty:ignore
    periodic_len = np.array(
        [
            sum(length for length, pbc in zip(struct.cell.lengths(), struct.pbc) if pbc)  # ty:ignore
            for struct in struct_list
        ]
    )

    ### Sort indices first by 'periodic length', then 'number of atoms' and "composition"
    sorted_indices = np.lexsort((compo_num, atom_num, periodic_len))
    sorted_task_dirs = [task_dirs[i] for i in sorted_indices]
    return sorted_task_dirs
